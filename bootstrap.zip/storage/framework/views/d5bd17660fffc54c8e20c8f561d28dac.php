
<?php $__env->startSection('main'); ?>
<section class="section-3 py-5 bg-2 ">
    <div class="container">     
        <div class="row">
            <div class="col-6 col-md-10 ">
                <h2>Find Jobs</h2>  
            </div>
            <div class="col-6 col-md-2">
                <div class="align-end">
                    <select name="sort" id="sort" class="form-control">
                        <option value="1" <?php echo e(Request::get('sort')=='1'?'selected':''); ?>>Latest</option>
                        <option value="0" <?php echo e(Request::get('sort')=='0'?'selected':''); ?>>Oldest</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="row pt-5">
            <div class="col-md-4 col-lg-3 sidebar mb-4">
                <form name="jobSearch" id="jobSearch">
                    <div class="card border-0 shadow p-4">
                        <div class="mb-4">
                            <h2>Keywords</h2>
                            <input type="text" placeholder="keywords" class="form-control" name="keywords" id="keywords" value="<?php echo e(request()->keywords); ?>">
                        </div>

                        <div class="mb-4">
                            <h2>Location</h2>
                            <input type="text" placeholder="Location" class="form-control" name="location" id="location" value="<?php echo e(request()->location); ?>">
                        </div>

                        <div class="mb-4">
                            <h2>Category</h2>
                            <select name="category" id="category" class="form-control">
                                <option value="">Select a Category</option>
                                <?php if($categories->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"  <?php echo e($category->id == Request::get('category') ? 'selected':''); ?> ><?php echo e($category->name); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>                   

                        <div class="mb-4">
                            <h2>Job Type</h2>
                            
                            <?php if($jobTypes->isNotEmpty()): ?>
                                <?php $__currentLoopData = $jobTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check mb-2"> 
                                        <input class="form-check-input " name="job_type" type="checkbox" value="<?php echo e($jobType->id); ?>" id="job_type_<?php echo e($jobType->id); ?>"
                                        <?php echo e(in_array($jobType->id, $jobTypeArr)? 'checked':''); ?>>    
                                        <label class="form-check-label " for="job_type_<?php echo e($jobType->id); ?>"><?php echo e($jobType->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                            <?php endif; ?>

                            
                        </div>

                        <div class="mb-4">
                            <h2>Experience</h2>
                            <select name="experience" id="experience" class="form-control">
                                <option value="">Select Experience</option>
                                <option value="1" <?php echo e(Request::get('experience')== 1? 'selected':''); ?> >1 Year</option>
                                <option value="2" <?php echo e(Request::get('experience')== 2? 'selected':''); ?>>2 Years</option>
                                <option value="3" <?php echo e(Request::get('experience')== 3? 'selected':''); ?>>3 Years</option>
                                <option value="4" <?php echo e(Request::get('experience')== 4? 'selected':''); ?>>4 Years</option>
                                <option value="5" <?php echo e(Request::get('experience')== 5? 'selected':''); ?>>5 Years</option>
                                <option value="6" <?php echo e(Request::get('experience')== 6? 'selected':''); ?>>6 Years</option>
                                <option value="7" <?php echo e(Request::get('experience')== 7? 'selected':''); ?>>7 Years</option>
                                <option value="8" <?php echo e(Request::get('experience')== 8? 'selected':''); ?>>8 Years</option>
                                <option value="9" <?php echo e(Request::get('experience')== 9? 'selected':''); ?>>9 Years</option>
                                <option value="10" <?php echo e(Request::get('experience')== 10? 'selected':''); ?>>10 Years</option>
                                <option value="10_plus" <?php echo e(Request::get('experience')== '10_plus'? 'selected':''); ?>>10+ Years</option>
                            </select>
                        </div>   
                        <button type="submit" name="submit">Search</button>
                       <a href="<?php echo e(route('jobs')); ?>" class="btn bt-secondary mt-3">Reset</a>                          
                    </div>
                   
                </form>
            </div>
            <div class="col-md-8 col-lg-9 ">
                <div class="job_listing_area">                    
                    <div class="job_lists">
                    <div class="row">
                        <?php if($jobs->isNotEmpty()): ?>
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card border-0 p-3 shadow mb-4">
                                    <div class="card-body">
                                        <h3 class="border-0 fs-5 pb-2 mb-0"><?php echo e($job->title); ?></h3>
                                        <p><?php echo e(Str::words($job->description,10)); ?></p>
                                        <p>Keywords : <?php echo e($job->keywords); ?></p>
                                        <p>Location: <?php echo e($job->location); ?></p>
                                        <p>Category: <?php echo e($job->category->name); ?></p>
                                        <p>JobType: <?php echo e($job->jobType->name); ?> - <?php echo e($job->job_type_id); ?><br>
                                        Exp: <?php echo e($job->experience); ?>

                                        </p>
                                        
                                        <div class="bg-light p-3 border">
                                            <p class="mb-0">
                                                <span class="fw-bolder"><i class="fa fa-map-marker"></i></span>
                                                <span class="ps-1"><?php echo e($job->location); ?></span>
                                            </p>
                                            <p class="mb-0">
                                                <span class="fw-bolder"><i class="fa fa-clock-o"></i></span>
                                                <span class="ps-1"><?php echo e($job->jobType->name); ?></span>
                                            </p>
                                            <p class="mb-0">
                                                <span class="fw-bolder"><i class="fa fa-usd"></i></span>
                                                <span class="ps-1"><?php echo e($job->salary); ?></span>
                                            </p>
                                        </div>

                                        <div class="d-grid mt-3">
                                            <a href="<?php echo e(route('jobDetail',$job->id)); ?>" class="btn btn-primary btn-lg">Details</a>
                                        </div>
                                     
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div>  <?php echo e($jobs->links()); ?> </div>
                        <?php endif; ?>
                        
                                           
                    </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
<script>
    $('#jobSearch').submit(function(e){
        e.preventDefault();
        let url = '<?php echo e(route('jobs')); ?>?';
        
        let keywords = $('#keywords').val();
        let category = $('#category').val();
        let job_type = $('#job_type').val();
        let location = $('#location').val();
        let experience = $('#experience').val();
      
        if(keywords!=''){
            url += '&keywords='+keywords;
        }
        if(category!=''){
            url += '&category='+category;
        }
        
        if(location!=''){
            url += '&location='+location;
        }
        if(experience!=''){
            url += '&experience='+experience;
        }

        let jobTypesArr= $("input:checkbox[name='job_type']:checked").map(function(){
                return $(this).val();
        }).get();
        if(jobTypesArr.length){
            url += '&job_type='+jobTypesArr;
        }
        let sort = $('#sort').val();
        if(sort!=''){
            url +='&sort='+sort;
        }
        //console.log(jobTypesArr);
      

        window.location.href=url;
    });

    $('#sort').change(function(){
        $('#jobSearch').submit();
    });
</script>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-projs\jobportal\resources\views/front/jobs.blade.php ENDPATH**/ ?>