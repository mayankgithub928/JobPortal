<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Notification</title>
</head>
<body>
    <h1> Hello <?php echo e($mailData['employer']->name); ?> </h1>
    <p>Job Title: <?php echo e($mailData['job']->title); ?> </p>

    <p>User Name: <?php echo e($mailData['user']->name); ?> </p>
    <p>User Email: <?php echo e($mailData['user']->email); ?> </p>
    <p>Mobile: <?php echo e($mailData['user']->mobile); ?> </p>
</body>
</html><?php /**PATH D:\laravel-projs\jobportal\resources\views/email/job-notification.blade.php ENDPATH**/ ?>