@extends('front.layout.app')

@section('main')
<h1>This Is contact page text coming from child page</h1>
@endsection